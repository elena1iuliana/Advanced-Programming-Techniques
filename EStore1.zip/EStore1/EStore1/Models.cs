﻿using System;
using System.Collections.Generic;

namespace EStore
{
    public static class BazaDeDate
    {
        public static List<Produs> Catalog = new List<Produs> {
            new Produs { Id = 1, Name = "Laptop Gaming", Price = 5000 },
            new Produs { Id = 2, Name = "Mouse Wireless", Price = 250 }
        };
        public static List<Order> ToateComenzile = new List<Order>();
    }

    public class Produs
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public double Price { get; set; }
    }

    public abstract class User { public string Username { get; set; } }
    public class Customer : User { public string Adresa { get; set; } }

    public class Admin : User
    {
        public void AdaugaProdusNou(int id, string nume, double pret)
        {
            BazaDeDate.Catalog.Add(new Produs { Id = id, Name = nume, Price = pret });
            Console.WriteLine($"\n[ADMIN] SUCCES: Produsul '{nume}' a fost adăugat în magazin.");
        }

        public void VeziComenzi()
        {
            Console.WriteLine("\n--- PANOU ADMIN: TOATE COMENZILE ---");
            if (BazaDeDate.ToateComenzile.Count == 0) Console.WriteLine("Nu există comenzi plasate.");
            foreach (var o in BazaDeDate.ToateComenzile)
            {
                Console.WriteLine($"ID: {o.OrderId} | Client: {o.CustomerName} | Status: {o.Status} | Total: {o.PretFinal} RON");
            }
        }
    }

    public class ShoppingCart
    {
        public List<Produs> ProduseInCos = new List<Produs>();
        public void Add(Produs p) { ProduseInCos.Add(p); Console.WriteLine($" + {p.Name} adăugat."); }
    }
}