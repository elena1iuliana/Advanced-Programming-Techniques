﻿using System;
using System.Collections.Generic;

namespace EStore
{
    public enum StatusComanda { InAsteptare, Expediata, Anulata }

    public class Order
    {
        public string OrderId { get; set; }
        public string CustomerName { get; set; }
        public StatusComanda Status { get; set; }
        public double PretFinal { get; set; }

        private List<Produs> _produse;
        private IDiscountStrategy _discount;

        public Order(Customer c, ShoppingCart cos, IDiscountStrategy disc)
        {
            OrderId = "CMD-" + new Random().Next(100, 999);
            CustomerName = c.Username;
            _produse = new List<Produs>(cos.ProduseInCos);
            _discount = disc;
            Status = StatusComanda.InAsteptare;
        }

        public void Finalizeaza()
        {
            double total = 0;
            foreach (var p in _produse) total += p.Price;
            PretFinal = _discount.ApplyDiscount(total);

            Console.WriteLine($"\nComandă plasată! ID: {OrderId} | Total: {PretFinal} RON");
            BazaDeDate.ToateComenzile.Add(this); 
        }
    }
}