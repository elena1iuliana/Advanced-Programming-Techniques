﻿using System;

namespace EStore
{
    public interface IPaymentStrategy { void Pay(double amount); }
    public interface IShippingStrategy { void Ship(string address); }
    public interface IDiscountStrategy
    {
        string CampaignName { get; }
        double ApplyDiscount(double price);
    }

    public class CardPayment : IPaymentStrategy
    {
        public void Pay(double amount) => Console.WriteLine($"[Plată] Suma de {amount} RON achitată prin Card.");
    }

    public class FanCourier : IShippingStrategy
    {
        public void Ship(string address) => Console.WriteLine($"[Livrare] Expediere FanCourier către: {address}");
    }

    public class BlackFridayDiscount : IDiscountStrategy
    {
        public string CampaignName => "Black Friday (20%)";
        public double ApplyDiscount(double price) => price * 0.8;
    }

    public class StudentDiscount : IDiscountStrategy
    {
        public string CampaignName => "Student Discount (15%)";
        public double ApplyDiscount(double price) => price * 0.85;
    }

    public class NoDiscount : IDiscountStrategy
    {
        public string CampaignName => "Preț Întreg";
        public double ApplyDiscount(double price) => price;
    }
}