﻿using System;

namespace EStore
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                Console.WriteLine("\n=== INTERFAȚĂ MAGAZIN ===");
                Console.WriteLine("1. Intru ca CLIENT | 2. Intru ca ADMIN | 0. Ieșire");
                string opt = Console.ReadLine();

                if (opt == "0") break;
                if (opt == "2") MeniuAdmin();
                else MeniuClient();
            }
        }

        static void MeniuAdmin()
        {
            Admin admin = new Admin { Username = "Sefu" };
            while (true)
            {
                Console.WriteLine($"\n--- ADMIN: {admin.Username} ---");
                Console.WriteLine("1. Adaugă Produs Nou\n2. Vezi Toate Comenzile\n3. Schimbă Status Comandă\n0. Logout");
                string aOpt = Console.ReadLine();
                if (aOpt == "0") break;

                if (aOpt == "1")
                {
                    Console.Write("ID: "); int id = int.Parse(Console.ReadLine());
                    Console.Write("Nume: "); string nume = Console.ReadLine();
                    Console.Write("Pret: "); double pret = double.Parse(Console.ReadLine());
                    admin.AdaugaProdusNou(id, nume, pret);
                }
                else if (aOpt == "2") admin.VeziComenzi();
                else if (aOpt == "3")
                {
                    admin.VeziComenzi();
                    Console.Write("Introdu ID Comandă: "); string idC = Console.ReadLine();
                    var cmd = BazaDeDate.ToateComenzile.Find(x => x.OrderId == idC);
                    if (cmd != null)
                    {
                        Console.WriteLine("Status: 1. Expediata | 2. Anulata");
                        cmd.Status = Console.ReadLine() == "1" ? StatusComanda.Expediata : StatusComanda.Anulata;
                        Console.WriteLine("Status actualizat!");
                    }
                }
            }
        }

        static void MeniuClient()
        {
            Console.Write("Numele tău: "); string nume = Console.ReadLine();
            Customer c = new Customer { Username = nume, Adresa = "Acasa" };
            ShoppingCart cos = new ShoppingCart();

            Console.WriteLine("\n--- CATALOG PRODUSE ---");
            foreach (var p in BazaDeDate.Catalog) Console.WriteLine($"{p.Id}. {p.Name} - {p.Price} RON");

            while (true)
            {
                Console.Write("Introdu ID produs (0 pt Final): ");
                int id = int.Parse(Console.ReadLine());
                if (id == 0) break;
                var p = BazaDeDate.Catalog.Find(x => x.Id == id);
                if (p != null) cos.Add(p);
            }

            if (cos.ProduseInCos.Count > 0)
            {
                Console.WriteLine("Discount: 1. Student (15%) | 2. Black Friday (20%) | 3. Fara");
                string d = Console.ReadLine();
                IDiscountStrategy disc = d == "1" ? new StudentDiscount() : (d == "2" ? new BlackFridayDiscount() : new NoDiscount());

                Order o = new Order(c, cos, disc);
                o.Finalizeaza();
            }
        }
    }
}